#include <stdio.h>
int main()
{
	printf("Hello Git!\n");
	printf("Hello GitdiffTool!\n");
	printf("Hello diff!\n");
	printf("git commit -v (Use diff)!\n");
	printf("Sha\n");
	printf("skip temp");
	return 0;
}
