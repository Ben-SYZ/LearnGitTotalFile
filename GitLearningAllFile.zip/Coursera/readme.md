CannotPushForce is the directory that need to be figure out in the future. I rebase the remote,which has been merged.

HTML2 is temp direcory, there is some pointers in it. It can be delete.

HTMLBACKUP is the directory which has the pointer of upstream, upstrean... Maybe need to be figure in the future.

html firstly build for git learning. Then used as remote repository.

htmlback is used as the local repository.

